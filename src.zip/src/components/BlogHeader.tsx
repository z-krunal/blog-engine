import { BlogPost } from '../types/blog';
import { formatDate } from '../utils/formatDate';


interface BlogHeaderProps {
  post: BlogPost;
}

export default function BlogHeader({ post }: BlogHeaderProps) {
  return (
    <header className="text-center max-w-3xl mx-auto">
        {post.tags && post.tags.length > 0 && (
        <div className="mb-6 flex flex-wrap justify-center gap-2">
          {post.tags.map((tag) => (
            <span
              key={tag}
              className="inline-flex items-center rounded-full bg-blue-50 px-3 py-1 text-sm font-medium text-blue-700 hover:bg-blue-100 transition-colors cursor-pointer"
            >
              {tag}
            </span>
          ))}
        </div>
      )}

          <h1 className="mb-4 text-4xl font-bold tracking-tight text-gray-900 sm:text-5xl text-center">
          {post.title}
        </h1>

        <div className="mb-4 text-sm text-gray-500">
          <time dateTime={post.date}>{formatDate(post.date)}</time>
          {post.author && <span> · By {post.author}</span>}
          {post.readingTime && <span> · {post.readingTime} min read</span>}
        </div>

        {post.description && (
          <p className="mb-6 text-lg leading-8 text-gray-600">
            {post.description}
          </p>
        )}
</header>
  );
} 