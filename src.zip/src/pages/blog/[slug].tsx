import type { BlogPost, BlogPostPageProps } from '../../types/blog';
import BlogHeader from '../../components/BlogHeader';
import BlogCoverImage from '../../components/BlogCoverImage';
import MDXContent from '../../components/MDXContent';
import ShareButtons from '../../components/ShareButtons';
import { GetStaticProps, GetStaticPaths } from 'next';
import { getPostBySlug, getAllPosts } from '../../mdx';

export default function BlogPost({ post }: BlogPostPageProps) {
  console.log('Post data:', {
    title: post.title,
    tags: post.tags,
    typeofTags: typeof post.tags,
    isArray: Array.isArray(post.tags)
  });

  return (
    <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8 text-center">
        {/* Blog Header Section */}
        <section className="mb-12">
          <BlogHeader post={post} />
        </section>

        {/* Cover Image Section */}
        {post.image && (
          <section className="mb-12">
            <BlogCoverImage src={post.image} alt={post.title} />
          </section>
        )}

      <div className="py-8">
        {/* MDX Content Section */}
        <section className="mb-12">
          <MDXContent source={post.mdxSource} />
        </section>

        {/* Share Section */}
        <section className="mt-12 text-center">
          <ShareButtons 
            url={`/blog/${post.slug}`}
            title={post.title}
            description={post.description}
          />
        </section>
      </div>
    </div>
  );
}

export const getStaticPaths: GetStaticPaths = async () => {
  const posts = await getAllPosts({
    showOn: 'krunalsabnis', // or process.env.SITE_ID
    baseDir: process.cwd()
  });

  return {
    paths: posts.map((post) => ({
      params: { slug: post.slug }
    })),
    fallback: false
  };
};

export const getStaticProps: GetStaticProps<BlogPostPageProps> = async ({ params }) => {
  const post = await getPostBySlug(params?.slug as string, {
    showOn: 'krunalsabnis', // or process.env.SITE_ID
    baseDir: process.cwd()
  });

  return {
    props: {
      post
    }
  };
}; 